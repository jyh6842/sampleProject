package data;

import vo.UserVO;

public class Session {
	
	// 로그인 되어있는 유저의 정보를 저장 // 게시글 쓸때 이사람이 쓸수 있도록도 한다.
	public static UserVO loginUser;
}
